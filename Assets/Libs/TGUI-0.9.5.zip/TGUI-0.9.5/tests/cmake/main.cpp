#include <TGUI/TGUI.hpp>

int main()
{
    sf::RenderTexture target;
    tgui::Gui gui{target};
}
