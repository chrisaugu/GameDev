This folder contains the [texus/nanosvg](https://github.com/texus/nanosvg) headers, which contain only minor changes to the official [memononen/nanosvg](https://github.com/memononen/nanosvg) library.
