using namespace std;
#include<iostream>
#include<stdio.h>
int main()
{   int t =TTF_Init();

cout<<t;

return 0;
}
