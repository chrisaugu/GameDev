# Bike-Racing-Game
code
The Bike Race Game in C++ is a console application game development project. It is interesting, simple to play and demonstrates the use of various features of C++ programming language and SDL. 
In order to enhance the aesthetic of the game, I have utilized the application of graphics in the game to make the game more realistic. The project is mainly focused on the use of SDL in C++; SDL is a popular 2D gaming graphics.
The source code of the Bike Race Game in C++ is written in C++ project format and is compiled in Code::Blocks IDE using GCC compiler. The source code of the game consists of eight user defined header files and a number of user defined functions  are within them to perform certain specific tasks. 
